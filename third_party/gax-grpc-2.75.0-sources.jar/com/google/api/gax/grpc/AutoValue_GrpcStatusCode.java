package com.google.api.gax.grpc;

import io.grpc.Status;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_GrpcStatusCode extends GrpcStatusCode {

  private final Status.Code transportCode;

  AutoValue_GrpcStatusCode(
      Status.Code transportCode) {
    if (transportCode == null) {
      throw new NullPointerException("Null transportCode");
    }
    this.transportCode = transportCode;
  }

  @Override
  public Status.Code getTransportCode() {
    return transportCode;
  }

  @Override
  public String toString() {
    return "GrpcStatusCode{"
        + "transportCode=" + transportCode
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof GrpcStatusCode) {
      GrpcStatusCode that = (GrpcStatusCode) o;
      return this.transportCode.equals(that.getTransportCode());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= transportCode.hashCode();
    return h$;
  }

}
