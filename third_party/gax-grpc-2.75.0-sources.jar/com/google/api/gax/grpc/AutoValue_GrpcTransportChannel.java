package com.google.api.gax.grpc;

import io.grpc.ManagedChannel;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_GrpcTransportChannel extends GrpcTransportChannel {

  private final ManagedChannel managedChannel;

  private final boolean directPath;

  private AutoValue_GrpcTransportChannel(
      ManagedChannel managedChannel,
      boolean directPath) {
    this.managedChannel = managedChannel;
    this.directPath = directPath;
  }

  @Override
  ManagedChannel getManagedChannel() {
    return managedChannel;
  }

  @Override
  public boolean isDirectPath() {
    return directPath;
  }

  @Override
  public String toString() {
    return "GrpcTransportChannel{"
        + "managedChannel=" + managedChannel + ", "
        + "directPath=" + directPath
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof GrpcTransportChannel) {
      GrpcTransportChannel that = (GrpcTransportChannel) o;
      return this.managedChannel.equals(that.getManagedChannel())
          && this.directPath == that.isDirectPath();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= managedChannel.hashCode();
    h$ *= 1000003;
    h$ ^= directPath ? 1231 : 1237;
    return h$;
  }

  static final class Builder extends GrpcTransportChannel.Builder {
    private ManagedChannel managedChannel;
    private boolean directPath;
    private byte set$0;
    Builder() {
    }
    @Override
    public GrpcTransportChannel.Builder setManagedChannel(ManagedChannel managedChannel) {
      if (managedChannel == null) {
        throw new NullPointerException("Null managedChannel");
      }
      this.managedChannel = managedChannel;
      return this;
    }
    @Override
    GrpcTransportChannel.Builder setDirectPath(boolean directPath) {
      this.directPath = directPath;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public GrpcTransportChannel build() {
      if (set$0 != 1
          || this.managedChannel == null) {
        StringBuilder missing = new StringBuilder();
        if (this.managedChannel == null) {
          missing.append(" managedChannel");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" directPath");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_GrpcTransportChannel(
          this.managedChannel,
          this.directPath);
    }
  }

}
