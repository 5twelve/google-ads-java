package com.google.api.gax.rpc;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_PageContext<RequestT, ResponseT, ResourceT> extends PageContext<RequestT, ResponseT, ResourceT> {

  private final UnaryCallable<RequestT, ResponseT> callable;

  private final PagedListDescriptor<RequestT, ResponseT, ResourceT> pageDescriptor;

  private final RequestT request;

  private final ApiCallContext callContext;

  AutoValue_PageContext(
      UnaryCallable<RequestT, ResponseT> callable,
      PagedListDescriptor<RequestT, ResponseT, ResourceT> pageDescriptor,
      RequestT request,
      ApiCallContext callContext) {
    if (callable == null) {
      throw new NullPointerException("Null callable");
    }
    this.callable = callable;
    if (pageDescriptor == null) {
      throw new NullPointerException("Null pageDescriptor");
    }
    this.pageDescriptor = pageDescriptor;
    if (request == null) {
      throw new NullPointerException("Null request");
    }
    this.request = request;
    if (callContext == null) {
      throw new NullPointerException("Null callContext");
    }
    this.callContext = callContext;
  }

  @Override
  public UnaryCallable<RequestT, ResponseT> getCallable() {
    return callable;
  }

  @Override
  public PagedListDescriptor<RequestT, ResponseT, ResourceT> getPageDescriptor() {
    return pageDescriptor;
  }

  @Override
  public RequestT getRequest() {
    return request;
  }

  @Override
  public ApiCallContext getCallContext() {
    return callContext;
  }

  @Override
  public String toString() {
    return "PageContext{"
        + "callable=" + callable + ", "
        + "pageDescriptor=" + pageDescriptor + ", "
        + "request=" + request + ", "
        + "callContext=" + callContext
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof PageContext) {
      PageContext<?, ?, ?> that = (PageContext<?, ?, ?>) o;
      return this.callable.equals(that.getCallable())
          && this.pageDescriptor.equals(that.getPageDescriptor())
          && this.request.equals(that.getRequest())
          && this.callContext.equals(that.getCallContext());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= callable.hashCode();
    h$ *= 1000003;
    h$ ^= pageDescriptor.hashCode();
    h$ *= 1000003;
    h$ ^= request.hashCode();
    h$ *= 1000003;
    h$ ^= callContext.hashCode();
    return h$;
  }

}
