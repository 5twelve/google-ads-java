package com.google.api.gax.rpc;

import java.util.Map;
import javax.annotation.Generated;
import javax.annotation.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_FixedHeaderProvider extends FixedHeaderProvider {

  @Nullable
  private final Map<String, String> headers;

  AutoValue_FixedHeaderProvider(
      @Nullable Map<String, String> headers) {
    this.headers = headers;
  }

  @Nullable
  @Override
  public Map<String, String> getHeaders() {
    return headers;
  }

  @Override
  public String toString() {
    return "FixedHeaderProvider{"
        + "headers=" + headers
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof FixedHeaderProvider) {
      FixedHeaderProvider that = (FixedHeaderProvider) o;
      return (this.headers == null ? that.getHeaders() == null : this.headers.equals(that.getHeaders()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (headers == null) ? 0 : headers.hashCode();
    return h$;
  }

  private static final long serialVersionUID = -4881534091594970538L;

}
