package com.google.api.gax.core;

import java.util.concurrent.ThreadFactory;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_InstantiatingExecutorProvider extends InstantiatingExecutorProvider {

  private final int executorThreadCount;

  private final ThreadFactory threadFactory;

  private AutoValue_InstantiatingExecutorProvider(
      int executorThreadCount,
      ThreadFactory threadFactory) {
    this.executorThreadCount = executorThreadCount;
    this.threadFactory = threadFactory;
  }

  @Override
  public int getExecutorThreadCount() {
    return executorThreadCount;
  }

  @Override
  public ThreadFactory getThreadFactory() {
    return threadFactory;
  }

  @Override
  public String toString() {
    return "InstantiatingExecutorProvider{"
        + "executorThreadCount=" + executorThreadCount + ", "
        + "threadFactory=" + threadFactory
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof InstantiatingExecutorProvider) {
      InstantiatingExecutorProvider that = (InstantiatingExecutorProvider) o;
      return this.executorThreadCount == that.getExecutorThreadCount()
          && this.threadFactory.equals(that.getThreadFactory());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= executorThreadCount;
    h$ *= 1000003;
    h$ ^= threadFactory.hashCode();
    return h$;
  }

  @Override
  public InstantiatingExecutorProvider.Builder toBuilder() {
    return new AutoValue_InstantiatingExecutorProvider.Builder(this);
  }

  static final class Builder extends InstantiatingExecutorProvider.Builder {
    private int executorThreadCount;
    private ThreadFactory threadFactory;
    private byte set$0;
    Builder() {
    }
    Builder(InstantiatingExecutorProvider source) {
      this.executorThreadCount = source.getExecutorThreadCount();
      this.threadFactory = source.getThreadFactory();
      set$0 = (byte) 1;
    }
    @Override
    public InstantiatingExecutorProvider.Builder setExecutorThreadCount(int executorThreadCount) {
      this.executorThreadCount = executorThreadCount;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public int getExecutorThreadCount() {
      if ((set$0 & 1) == 0) {
        throw new IllegalStateException("Property \"executorThreadCount\" has not been set");
      }
      return executorThreadCount;
    }
    @Override
    public InstantiatingExecutorProvider.Builder setThreadFactory(ThreadFactory threadFactory) {
      if (threadFactory == null) {
        throw new NullPointerException("Null threadFactory");
      }
      this.threadFactory = threadFactory;
      return this;
    }
    @Override
    public ThreadFactory getThreadFactory() {
      if (this.threadFactory == null) {
        throw new IllegalStateException("Property \"threadFactory\" has not been set");
      }
      return threadFactory;
    }
    @Override
    public InstantiatingExecutorProvider build() {
      if (set$0 != 1
          || this.threadFactory == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" executorThreadCount");
        }
        if (this.threadFactory == null) {
          missing.append(" threadFactory");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_InstantiatingExecutorProvider(
          this.executorThreadCount,
          this.threadFactory);
    }
  }

}
