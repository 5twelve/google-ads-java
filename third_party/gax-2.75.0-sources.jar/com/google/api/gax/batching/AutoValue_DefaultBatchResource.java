package com.google.api.gax.batching;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_DefaultBatchResource extends DefaultBatchResource {

  private final long elementCount;

  private final long byteCount;

  private AutoValue_DefaultBatchResource(
      long elementCount,
      long byteCount) {
    this.elementCount = elementCount;
    this.byteCount = byteCount;
  }

  @Override
  public long getElementCount() {
    return elementCount;
  }

  @Override
  public long getByteCount() {
    return byteCount;
  }

  @Override
  public String toString() {
    return "DefaultBatchResource{"
        + "elementCount=" + elementCount + ", "
        + "byteCount=" + byteCount
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof DefaultBatchResource) {
      DefaultBatchResource that = (DefaultBatchResource) o;
      return this.elementCount == that.getElementCount()
          && this.byteCount == that.getByteCount();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((elementCount >>> 32) ^ elementCount);
    h$ *= 1000003;
    h$ ^= (int) ((byteCount >>> 32) ^ byteCount);
    return h$;
  }

  static final class Builder extends DefaultBatchResource.Builder {
    private long elementCount;
    private long byteCount;
    private byte set$0;
    Builder() {
    }
    @Override
    DefaultBatchResource.Builder setElementCount(long elementCount) {
      this.elementCount = elementCount;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    DefaultBatchResource.Builder setByteCount(long byteCount) {
      this.byteCount = byteCount;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    DefaultBatchResource build() {
      if (set$0 != 3) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" elementCount");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" byteCount");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_DefaultBatchResource(
          this.elementCount,
          this.byteCount);
    }
  }

}
