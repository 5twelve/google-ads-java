package com.google.api.gax.logging;

import java.util.Map;
import javax.annotation.Generated;
import javax.annotation.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_LogData extends LogData {

  @Nullable
  private final String serviceName;

  @Nullable
  private final String rpcName;

  @Nullable
  private final String requestId;

  @Nullable
  private final Map<String, String> requestHeaders;

  @Nullable
  private final Map<String, Object> requestPayload;

  @Nullable
  private final String responseStatus;

  @Nullable
  private final Map<String, String> responseHeaders;

  @Nullable
  private final Map<String, Object> responsePayload;

  @Nullable
  private final String httpMethod;

  @Nullable
  private final String httpUrl;

  private AutoValue_LogData(
      @Nullable String serviceName,
      @Nullable String rpcName,
      @Nullable String requestId,
      @Nullable Map<String, String> requestHeaders,
      @Nullable Map<String, Object> requestPayload,
      @Nullable String responseStatus,
      @Nullable Map<String, String> responseHeaders,
      @Nullable Map<String, Object> responsePayload,
      @Nullable String httpMethod,
      @Nullable String httpUrl) {
    this.serviceName = serviceName;
    this.rpcName = rpcName;
    this.requestId = requestId;
    this.requestHeaders = requestHeaders;
    this.requestPayload = requestPayload;
    this.responseStatus = responseStatus;
    this.responseHeaders = responseHeaders;
    this.responsePayload = responsePayload;
    this.httpMethod = httpMethod;
    this.httpUrl = httpUrl;
  }

  @Nullable
  @Override
  public String serviceName() {
    return serviceName;
  }

  @Nullable
  @Override
  public String rpcName() {
    return rpcName;
  }

  @Nullable
  @Override
  public String requestId() {
    return requestId;
  }

  @Nullable
  @Override
  public Map<String, String> requestHeaders() {
    return requestHeaders;
  }

  @Nullable
  @Override
  public Map<String, Object> requestPayload() {
    return requestPayload;
  }

  @Nullable
  @Override
  public String responseStatus() {
    return responseStatus;
  }

  @Nullable
  @Override
  public Map<String, String> responseHeaders() {
    return responseHeaders;
  }

  @Nullable
  @Override
  public Map<String, Object> responsePayload() {
    return responsePayload;
  }

  @Nullable
  @Override
  public String httpMethod() {
    return httpMethod;
  }

  @Nullable
  @Override
  public String httpUrl() {
    return httpUrl;
  }

  @Override
  public String toString() {
    return "LogData{"
        + "serviceName=" + serviceName + ", "
        + "rpcName=" + rpcName + ", "
        + "requestId=" + requestId + ", "
        + "requestHeaders=" + requestHeaders + ", "
        + "requestPayload=" + requestPayload + ", "
        + "responseStatus=" + responseStatus + ", "
        + "responseHeaders=" + responseHeaders + ", "
        + "responsePayload=" + responsePayload + ", "
        + "httpMethod=" + httpMethod + ", "
        + "httpUrl=" + httpUrl
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof LogData) {
      LogData that = (LogData) o;
      return (this.serviceName == null ? that.serviceName() == null : this.serviceName.equals(that.serviceName()))
          && (this.rpcName == null ? that.rpcName() == null : this.rpcName.equals(that.rpcName()))
          && (this.requestId == null ? that.requestId() == null : this.requestId.equals(that.requestId()))
          && (this.requestHeaders == null ? that.requestHeaders() == null : this.requestHeaders.equals(that.requestHeaders()))
          && (this.requestPayload == null ? that.requestPayload() == null : this.requestPayload.equals(that.requestPayload()))
          && (this.responseStatus == null ? that.responseStatus() == null : this.responseStatus.equals(that.responseStatus()))
          && (this.responseHeaders == null ? that.responseHeaders() == null : this.responseHeaders.equals(that.responseHeaders()))
          && (this.responsePayload == null ? that.responsePayload() == null : this.responsePayload.equals(that.responsePayload()))
          && (this.httpMethod == null ? that.httpMethod() == null : this.httpMethod.equals(that.httpMethod()))
          && (this.httpUrl == null ? that.httpUrl() == null : this.httpUrl.equals(that.httpUrl()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (serviceName == null) ? 0 : serviceName.hashCode();
    h$ *= 1000003;
    h$ ^= (rpcName == null) ? 0 : rpcName.hashCode();
    h$ *= 1000003;
    h$ ^= (requestId == null) ? 0 : requestId.hashCode();
    h$ *= 1000003;
    h$ ^= (requestHeaders == null) ? 0 : requestHeaders.hashCode();
    h$ *= 1000003;
    h$ ^= (requestPayload == null) ? 0 : requestPayload.hashCode();
    h$ *= 1000003;
    h$ ^= (responseStatus == null) ? 0 : responseStatus.hashCode();
    h$ *= 1000003;
    h$ ^= (responseHeaders == null) ? 0 : responseHeaders.hashCode();
    h$ *= 1000003;
    h$ ^= (responsePayload == null) ? 0 : responsePayload.hashCode();
    h$ *= 1000003;
    h$ ^= (httpMethod == null) ? 0 : httpMethod.hashCode();
    h$ *= 1000003;
    h$ ^= (httpUrl == null) ? 0 : httpUrl.hashCode();
    return h$;
  }

  static final class Builder extends LogData.Builder {
    private String serviceName;
    private String rpcName;
    private String requestId;
    private Map<String, String> requestHeaders;
    private Map<String, Object> requestPayload;
    private String responseStatus;
    private Map<String, String> responseHeaders;
    private Map<String, Object> responsePayload;
    private String httpMethod;
    private String httpUrl;
    Builder() {
    }
    @Override
    public LogData.Builder serviceName(String serviceName) {
      this.serviceName = serviceName;
      return this;
    }
    @Override
    public LogData.Builder rpcName(String rpcName) {
      this.rpcName = rpcName;
      return this;
    }
    @Override
    public LogData.Builder requestId(String requestId) {
      this.requestId = requestId;
      return this;
    }
    @Override
    public LogData.Builder requestHeaders(Map<String, String> requestHeaders) {
      this.requestHeaders = requestHeaders;
      return this;
    }
    @Override
    public LogData.Builder requestPayload(Map<String, Object> requestPayload) {
      this.requestPayload = requestPayload;
      return this;
    }
    @Override
    public LogData.Builder responseStatus(String responseStatus) {
      this.responseStatus = responseStatus;
      return this;
    }
    @Override
    public LogData.Builder responseHeaders(Map<String, String> responseHeaders) {
      this.responseHeaders = responseHeaders;
      return this;
    }
    @Override
    public LogData.Builder responsePayload(Map<String, Object> responsePayload) {
      this.responsePayload = responsePayload;
      return this;
    }
    @Override
    public LogData.Builder httpMethod(String httpMethod) {
      this.httpMethod = httpMethod;
      return this;
    }
    @Override
    public LogData.Builder httpUrl(String httpUrl) {
      this.httpUrl = httpUrl;
      return this;
    }
    @Override
    public LogData build() {
      return new AutoValue_LogData(
          this.serviceName,
          this.rpcName,
          this.requestId,
          this.requestHeaders,
          this.requestPayload,
          this.responseStatus,
          this.responseHeaders,
          this.responsePayload,
          this.httpMethod,
          this.httpUrl);
    }
  }

}
