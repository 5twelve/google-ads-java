package com.google.api.gax.tracing;

import javax.annotation.Generated;
import javax.annotation.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ApiTracerContext extends ApiTracerContext {

  @Nullable
  private final String serverAddress;

  private AutoValue_ApiTracerContext(
      @Nullable String serverAddress) {
    this.serverAddress = serverAddress;
  }

  @Nullable
  @Override
  public String getServerAddress() {
    return serverAddress;
  }

  @Override
  public String toString() {
    return "ApiTracerContext{"
        + "serverAddress=" + serverAddress
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ApiTracerContext) {
      ApiTracerContext that = (ApiTracerContext) o;
      return (this.serverAddress == null ? that.getServerAddress() == null : this.serverAddress.equals(that.getServerAddress()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (serverAddress == null) ? 0 : serverAddress.hashCode();
    return h$;
  }

  static final class Builder extends ApiTracerContext.Builder {
    private String serverAddress;
    Builder() {
    }
    @Override
    public ApiTracerContext.Builder setServerAddress(String serverAddress) {
      this.serverAddress = serverAddress;
      return this;
    }
    @Override
    public ApiTracerContext build() {
      return new AutoValue_ApiTracerContext(
          this.serverAddress);
    }
  }

}
